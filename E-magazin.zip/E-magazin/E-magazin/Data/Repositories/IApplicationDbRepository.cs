﻿using E_magazin.Data.Common;

namespace E_magazin.Data.Repositories
{
    public interface IApplicationDbRepository : IRepository
    {

    }
}
