﻿namespace E_magazin.ViewModels
{
    public class RestockViewModel
    {
        public int ProductId { get; set; }
        public double Amount { get; set; }
    }
}
